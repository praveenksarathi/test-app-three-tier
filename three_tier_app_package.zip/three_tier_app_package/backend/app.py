from flask import Flask, request, jsonify
import psycopg2

app = Flask(__name__)

@app.route('/')
def hello():
    return "Hello from Backend!"

@app.route('/health')
def health():
    return "OK", 200

@app.route('/data', methods=['POST', 'GET', 'DELETE'])
def data():
    if request.method == 'POST':
        return jsonify({"status": "data written"}), 201
    elif request.method == 'GET':
        return jsonify({"data": "sample data"}), 200
    elif request.method == 'DELETE':
        return jsonify({"status": "data deleted"}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
